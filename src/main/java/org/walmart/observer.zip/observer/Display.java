package org.walmart.observer;

public interface Display {

    void display();
}
